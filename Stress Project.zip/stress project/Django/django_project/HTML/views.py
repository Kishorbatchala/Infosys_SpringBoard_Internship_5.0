from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth.decorators import login_required
import joblib 
from django.http import HttpResponse


# Home Page View
def index_view(request):
    return render(request, 'index.html')

# About Page View
def about_view(request):
    return render(request, 'about.html')

import mysql.connector as sql
from django.contrib import messages
from django.shortcuts import render, redirect

# Signup View
import mysql.connector as sql
from django.contrib import messages
from django.shortcuts import render, redirect

def signup_view(request):
    if request.method == "POST":
        # Get form data
        username = request.POST.get('username')
        email = request.POST.get('email')
        contactnumber = request.POST.get('contactnumber')  # New field
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        errors = {}

        # Validate password match
        if password != confirm_password:
            errors['password_error'] = "Passwords do not match."
            return render(request, 'signup.html', {'errors': errors})

        try:
            # Connect to MySQL database
            conn = sql.connect(
                host="localhost",
                user="root",
                password="Abhi@15112000",
                database="humanstress"
            )
            cursor = conn.cursor()

            # Check if username or email already exists
            cursor.execute("SELECT COUNT(*) FROM signup WHERE username = %s OR email = %s", (username, email))
            if cursor.fetchone()[0] > 0:
                errors['duplicate_error'] = "Username or email already exists."
                return render(request, 'signup.html', {'errors': errors})

            # Insert user into the database
            cursor.execute(
                "INSERT INTO signup (username, email, contactnumber, password, cpassword) VALUES (%s, %s, %s, %s, %s)",
                (username, email, contactnumber, password, confirm_password)
            )
            conn.commit()
            messages.success(request, "Account created successfully!")
            return redirect('login')

        except sql.Error as e:
            messages.error(request, f"Database error: {e}")

        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()

    return render(request, 'signup.html')


# Login View
def login_view(request):
    if request.method == "POST":
        # Get login form data
        username = request.POST.get("username")
        password = request.POST.get("password")

        try:
            # Connect to MySQL database
            conn = sql.connect(
                host="localhost",
                user="root",
                password="Abhi@15112000",
                database="humanstress"
            )
            cursor = conn.cursor()

            # Query for user authentication
            cursor.execute("SELECT * FROM signup WHERE username = %s AND password = %s", (username, password))
            user = cursor.fetchone()

            if user:
                # Successful login
                messages.success(request, "Successfully logged in!")
                return redirect('dataentry')  # Replace with the appropriate redirect
            else:
                # Invalid credentials
                messages.error(request, "Invalid username or password.")
                return render(request, 'login.html')

        except sql.Error as e:
            messages.error(request, f"Database error: {e}")

        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()

    return render(request, 'login.html')


# Data Entry View
@login_required
def data_entry(request):
    return render(request, 'dataentry.html')  # Placeholder template for data entry

# Result View 
from django.shortcuts import render, redirect
from django.utils.translation import gettext as _f

@login_required
def result(request):
    return render(request, 'result.html')






